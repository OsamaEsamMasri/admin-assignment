
import json
import subprocess
from datetime import datetime
from pathlib import Path

import requests

MODEL = "qwen2.5:0.5b"
API_URL = "http://localhost:11434/api/generate"

# Only these safe commands can be executed.
COMMANDS = {
    "ip": ["ip", "-brief", "address"],
    "route": ["ip", "route"],
    "ping": ["ping", "-c", "2", "-W", "2", "1.1.1.1"],
    "dns": ["getent", "hosts", "example.com"],
    "ports": ["ss", "-tuln"],
    "hostname": ["hostname"],
    "memory": ["free", "-h"],
    "disk": ["df", "-h", "/"],
    "system": ["uname", "-a"],
}

REPORT_DIR = Path.home() / "network_admin_lab" / "agent_reports"
REPORT_DIR.mkdir(parents=True, exist_ok=True)


def ask_ai(prompt, json_mode=False):
    payload = {
        "model": MODEL,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0,
            "num_ctx": 1024,
            "num_predict": 180
        }
    }

    if json_mode:
        payload["format"] = "json"

    response = requests.post(
        API_URL,
        json=payload,
        timeout=180
    )
    response.raise_for_status()
    return response.json()["response"]


def execute_command(command_id):
    command = COMMANDS[command_id]
    print(f"\n[AGENT EXECUTING] {' '.join(command)}")

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=15,
            shell=False,
            check=False
        )
        output = (result.stdout + result.stderr)[:4000]
        if not output:
            output = "(No output)"

        print(output)
        return {
            "command": " ".join(command),
            "exit_code": result.returncode,
            "output": output
        }

    except (OSError, subprocess.TimeoutExpired) as error:
        print(f"Command error: {error}")
        return {
            "command": " ".join(command),
            "error": str(error)
        }


def main():
    print("=" * 55)
    print("     AI NETWORK ADMINISTRATOR AGENT")
    print("=" * 55)

    user_request = input("\nYour task: ").strip()

    if not user_request:
        print("Please enter a task.")
        return

    available = json.dumps(COMMANDS, indent=2)

    planning_prompt = f"""
You are a Linux Network Administrator AI Agent.

User request: {user_request}

Available safe commands:
{available}

Choose between 1 and 6 useful commands to investigate
the request. You may only choose keys from the list.

Return ONLY a JSON object in this exact format:
{{"commands": ["ip", "route", "ping"]}}

Do not invent commands or arguments.
"""

    print("\n[AI] Planning diagnostic commands...")

    try:
        decision = ask_ai(planning_prompt, json_mode=True)
        plan = json.loads(decision)
        selected = plan.get("commands", [])

        if not isinstance(selected, list):
            raise ValueError("Invalid command list")

        # Validate every AI choice.
        selected = list(dict.fromkeys(selected))

        if (
            not selected
            or len(selected) > 6
            or any(
                not isinstance(item, str)
                or item not in COMMANDS
                for item in selected
            )
        ):
            raise ValueError("AI selected invalid commands")

        print("\n[AI PLAN]", selected)

        results = {}
        for command_id in selected:
            results[command_id] = execute_command(command_id)

        analysis_prompt = f"""
You are a Linux network administrator.

Original task:
{user_request}

Actual diagnostic results:
{json.dumps(results, separators=(',', ':'))[:1800]}

Write a concise English report containing:
1. Commands executed
2. Findings from the actual results
3. Problems detected, if any
4. Recommended next steps

Do not invent test results.
Do not claim a check passed if it failed.
"""

        print("\n[AI] Analyzing results...")
        analysis = ask_ai(analysis_prompt)

        print("\n========== AI ANALYSIS ==========")
        print(analysis)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_path = REPORT_DIR / f"report_{timestamp}.txt"

        report = (
            "AI NETWORK ADMINISTRATOR REPORT\n"
            f"Date: {datetime.now().isoformat()}\n"
            f"Task: {user_request}\n\n"
            "EXECUTION RESULTS\n"
            + json.dumps(results, indent=2)
            + "\n\nAI ANALYSIS\n"
            + analysis
        )

        report_path.write_text(report, encoding="utf-8")

        print(f"\n[SUCCESS] Report saved: {report_path}")

    except (
        requests.RequestException,
        ValueError,
        KeyError,
        json.JSONDecodeError
    ) as error:
        print(f"\n[ERROR] {error}")
        print("No unapproved commands were executed.")


if __name__ == "__main__":
    main()
